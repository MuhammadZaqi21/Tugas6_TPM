# MVP-Sales-Record
MVP- room database implementation (SQLite)

[![Build](https://github.com/Praktikum-TPM-C/MVP-Sales-Record/actions/workflows/gradle.yml/badge.svg)](https://github.com/Praktikum-TPM-C/MVP-Sales-Record/actions/workflows/gradle.yml)

## Author
123180164 </br>
Muhammad Ibnu Zaqi

## App Overview
- Home

![Home](assets/home.jpeg)

- Home (Detail List)

![Home](assets/detail.jpeg)

- Add Sales Record

![add](assets/add.jpeg)

- Bottom Sheet

![Bottom Sheet](assets/bottomsheet.jpeg)

- Change Sales Record

![change](assets/change.jpeg)

- Dialog Delete

![Dialog Delete](assets/dialog_delete.jpeg)
